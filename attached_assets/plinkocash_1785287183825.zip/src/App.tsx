import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  RiskLevel,
  BallType,
  GameSettings,
  PlayerStats,
  HistoryRecord,
} from './types';
import { storage } from './utils/storage';
import { soundManager } from './utils/audio';
import { Header } from './components/Header';
import { ControlPanel } from './components/ControlPanel';
import { PlinkoBoard } from './components/PlinkoBoard';
import { DailyRewardModal } from './components/DailyRewardModal';
import { InfoModal } from './components/InfoModal';
import { MobileFrame } from './components/MobileFrame';
import { SpinWheelModal } from './components/SpinWheelModal';
import { WithdrawModal } from './components/WithdrawModal';
import { AdRewardModal } from './components/AdRewardModal';

export default function App() {
  // Offline Saved States
  const [cash, setCash] = useState<number>(() => storage.getCash());
  const [ballsCount, setBallsCount] = useState<number>(() => {
    const saved = localStorage.getItem('plinko_balls_count');
    return saved ? parseInt(saved, 10) : 30;
  });
  const [settings, setSettings] = useState<GameSettings>(() => storage.getSettings());
  const [stats, setStats] = useState<PlayerStats>(() => storage.getStats());
  const [history, setHistory] = useState<HistoryRecord[]>(() => storage.getHistory());

  // Active Controls State
  const selectedBall: BallType = 'standard';
  const rows: number = 20;
  const risk: RiskLevel = 'high';
  const [isAutoDropping, setIsAutoDropping] = useState<boolean>(false);

  // Modals visibility
  const [isDailyOpen, setIsDailyOpen] = useState<boolean>(false);
  const [isInfoOpen, setIsInfoOpen] = useState<boolean>(false);
  const [isSpinWheelOpen, setIsSpinWheelOpen] = useState<boolean>(false);
  const [isWithdrawOpen, setIsWithdrawOpen] = useState<boolean>(false);
  const [isAdRewardOpen, setIsAdRewardOpen] = useState<boolean>(false);

  // Reference to Board drop function
  const dropBallRef = useRef<((type: BallType, bet: number) => void) | null>(null);

  // Sync sound manager with settings
  useEffect(() => {
    soundManager.setSoundEnabled(settings.soundEnabled);
    storage.saveSettings(settings);
  }, [settings]);

  // Save Cash, Balls & Stats whenever updated
  useEffect(() => {
    storage.setCash(cash);
  }, [cash]);

  useEffect(() => {
    localStorage.setItem('plinko_balls_count', ballsCount.toString());
  }, [ballsCount]);

  useEffect(() => {
    storage.saveStats(stats);
  }, [stats]);

  // Drop single ball action
  const handleDropBall = useCallback(() => {
    if (ballsCount <= 0) {
      setIsAutoDropping(false);
      setIsAdRewardOpen(true);
      return;
    }

    // Deduct 1 ball
    setBallsCount((prev) => Math.max(0, prev - 1));

    // Trigger board drop with base factor 1
    if (dropBallRef.current) {
      dropBallRef.current(selectedBall, 1);
    }

    // Update stats
    setStats((prev) => ({
      ...prev,
      totalDrops: prev.totalDrops + 1,
    }));
  }, [selectedBall, ballsCount]);

  // Handle ball landing callback from physics engine
  const handleBallLanded = useCallback(
    (payout: number, multiplier: number, ballType: BallType, goldenPegsHit: number) => {
      // Add payout to wallet cash
      setCash((prev) => prev + payout);

      // Record in history
      const newRecord: HistoryRecord = {
        id: `rec_${Date.now()}_${Math.random()}`,
        timestamp: Date.now(),
        bet: 1,
        multiplier,
        payout,
        ballType,
        risk,
        rows,
      };

      storage.addHistoryRecord(newRecord);
      setHistory((prev) => [newRecord, ...prev.slice(0, 49)]);

      // Update Player Stats
      setStats((prev) => ({
        ...prev,
        totalEarned: prev.totalEarned + payout,
        highestMultiplier: Math.max(prev.highestMultiplier, multiplier),
        highestSingleWin: Math.max(prev.highestSingleWin, payout),
        goldenPegsHit: prev.goldenPegsHit + goldenPegsHit,
      }));
    },
    [risk, rows]
  );

  // Auto drop timer loop
  useEffect(() => {
    if (!isAutoDropping) return;

    if (ballsCount <= 0) {
      setIsAutoDropping(false);
      setIsAdRewardOpen(true);
      return;
    }

    const interval = setInterval(() => {
      handleDropBall();
    }, settings.autoDropSpeed);

    return () => clearInterval(interval);
  }, [isAutoDropping, settings.autoDropSpeed, handleDropBall, ballsCount]);

  // Handle daily reward claim
  const handleClaimDaily = (amount: number) => {
    setCash((prev) => prev + amount);
  };

  // Spin Wheel Prize handler
  const handleWinSpinWheelPrize = (type: 'cash' | 'balls', value: number) => {
    if (type === 'cash') {
      setCash((prev) => prev + value);
    } else if (type === 'balls') {
      setBallsCount((prev) => prev + value);
    }
  };

  // Withdraw Handler
  const handleWithdraw = (amount: number) => {
    setCash((prev) => Math.max(0, prev - amount));
  };

  // Claim Ad Balls
  const handleClaimAdBalls = (count: number) => {
    setBallsCount((prev) => prev + count);
  };

  // Exchange Points for Balls (50 Points = 1 Ball)
  const handleExchangePoints = (pointsDeducted: number, ballsGained: number) => {
    setCash((prev) => Math.max(0, prev - pointsDeducted));
    setBallsCount((prev) => prev + ballsGained);
  };

  // Reset progress data
  const handleResetData = () => {
    storage.resetData();
    setCash(5000);
    setBallsCount(30);
    setStats(storage.getStats());
    setHistory([]);
  };

  return (
    <MobileFrame enabled={settings.mobileFrame}>
      <div id="app-root" className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-amber-500 selection:text-slate-950">
        {/* Navigation Header Bar */}
        <Header
          cash={cash}
          ballsCount={ballsCount}
          settings={settings}
          setSettings={setSettings}
          onOpenDaily={() => setIsDailyOpen(true)}
          onOpenInfo={() => setIsInfoOpen(true)}
          onOpenSpinWheel={() => setIsSpinWheelOpen(true)}
          onOpenWithdraw={() => setIsWithdrawOpen(true)}
          onOpenAdReward={() => setIsAdRewardOpen(true)}
        />

        {/* Main Game Arena Content */}
        <main className="flex-1 max-w-5xl w-full mx-auto p-2 sm:p-5 flex flex-col lg:grid lg:grid-cols-12 gap-3 sm:gap-5 items-center lg:items-start justify-start">
          {/* Physics Plinko Board */}
          <section className="w-full lg:col-span-7 flex flex-col items-center justify-center">
            <PlinkoBoard
              rows={rows}
              risk={risk}
              settings={settings}
              onBallLanded={handleBallLanded}
              onDropRef={dropBallRef}
            />
          </section>

          {/* Interactive Controls Panel */}
          <section className="w-full lg:col-span-5 flex flex-col gap-3 sticky bottom-2 sm:relative sm:bottom-0 z-20">
            <ControlPanel
              cash={cash}
              onDropBall={handleDropBall}
              isAutoDropping={isAutoDropping}
              setIsAutoDropping={setIsAutoDropping}
              settings={settings}
            />
          </section>
        </main>

        {/* Modals */}
        <SpinWheelModal
          isOpen={isSpinWheelOpen}
          onClose={() => setIsSpinWheelOpen(false)}
          onWinPrize={handleWinSpinWheelPrize}
          onOpenAdReward={() => setIsAdRewardOpen(true)}
          settings={settings}
        />

        <WithdrawModal
          isOpen={isWithdrawOpen}
          onClose={() => setIsWithdrawOpen(false)}
          cash={cash}
          onWithdraw={handleWithdraw}
          settings={settings}
        />

        <AdRewardModal
          isOpen={isAdRewardOpen}
          onClose={() => setIsAdRewardOpen(false)}
          onClaimBalls={handleClaimAdBalls}
          cash={cash}
          onExchangePoints={handleExchangePoints}
          settings={settings}
        />

        <DailyRewardModal
          isOpen={isDailyOpen}
          onClose={() => setIsDailyOpen(false)}
          onClaimReward={handleClaimDaily}
          settings={settings}
        />

        <InfoModal
          isOpen={isInfoOpen}
          onClose={() => setIsInfoOpen(false)}
          settings={settings}
        />
      </div>
    </MobileFrame>
  );
}
