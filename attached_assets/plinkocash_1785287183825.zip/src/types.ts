export type RiskLevel = 'low' | 'medium' | 'high';

export type BallType = 'standard' | 'golden' | 'splitter' | 'bomb' | 'magnet';

export interface BallInfo {
  id: BallType;
  name: string;
  nameId: string;
  description: string;
  descriptionId: string;
  costMultiplier: number;
  color: string;
  glowColor: string;
  icon: string;
  unlocked: boolean;
  unlockRequirement?: string;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  radius: number;
  alpha: number;
  life: number;
  maxLife: number;
  text?: string;
}

export interface Peg {
  x: number;
  y: number;
  radius: number;
  isGolden?: boolean;
  isHit?: boolean;
  hitTime?: number;
  hitCount?: number;
  valueBonus?: number;
}

export interface Ball {
  id: string;
  type: BallType;
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  color: string;
  betAmount: number;
  isGolden?: boolean;
  isSplitter?: boolean;
  hasSplit?: boolean;
  trail: { x: number; y: number; alpha: number }[];
}

export interface MultiplierBucket {
  index: number;
  x: number;
  width: number;
  multiplier: number;
  label: string;
  color: string;
  type?: 'number' | 'zonk' | 'ads';
  highlightTime?: number;
}

export interface HistoryRecord {
  id: string;
  timestamp: number;
  bet: number;
  multiplier: number;
  payout: number;
  ballType: BallType;
  risk: RiskLevel;
  rows: number;
}

export interface PlayerStats {
  totalDrops: number;
  totalSpent: number;
  totalEarned: number;
  highestMultiplier: number;
  highestSingleWin: number;
  stagesCompleted: number;
  goldenPegsHit: number;
  lastDailyBonus: number;
}

export interface GameSettings {
  soundEnabled: boolean;
  language: 'id' | 'en';
  autoDropSpeed: number; // ms delay
  mobileFrame: boolean;
  deviceType: 'ios' | 'android';
}
