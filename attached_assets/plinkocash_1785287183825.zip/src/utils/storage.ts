import { PlayerStats, GameSettings, HistoryRecord } from '../types';

const STORAGE_KEYS = {
  CASH: 'plinko_cash_balance',
  STATS: 'plinko_player_stats',
  SETTINGS: 'plinko_game_settings',
  HISTORY: 'plinko_drop_history',
};

const DEFAULT_SETTINGS: GameSettings = {
  soundEnabled: true,
  language: 'id',
  autoDropSpeed: 400,
  mobileFrame: false,
  deviceType: 'ios',
};

const DEFAULT_STATS: PlayerStats = {
  totalDrops: 0,
  totalSpent: 0,
  totalEarned: 0,
  highestMultiplier: 0,
  highestSingleWin: 0,
  stagesCompleted: 0,
  goldenPegsHit: 0,
  lastDailyBonus: 0,
};

export const storage = {
  // Cash balance
  getCash: (): number => {
    try {
      const val = localStorage.getItem(STORAGE_KEYS.CASH);
      return val !== null ? parseFloat(val) : 5000; // Starting $5,000 cash
    } catch {
      return 5000;
    }
  },

  setCash: (amount: number): void => {
    try {
      localStorage.setItem(STORAGE_KEYS.CASH, amount.toString());
    } catch {}
  },

  // Settings
  getSettings: (): GameSettings => {
    try {
      const val = localStorage.getItem(STORAGE_KEYS.SETTINGS);
      return val ? { ...DEFAULT_SETTINGS, ...JSON.parse(val) } : DEFAULT_SETTINGS;
    } catch {
      return DEFAULT_SETTINGS;
    }
  },

  saveSettings: (settings: GameSettings): void => {
    try {
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
    } catch {}
  },

  // Stats
  getStats: (): PlayerStats => {
    try {
      const val = localStorage.getItem(STORAGE_KEYS.STATS);
      return val ? { ...DEFAULT_STATS, ...JSON.parse(val) } : DEFAULT_STATS;
    } catch {
      return DEFAULT_STATS;
    }
  },

  saveStats: (stats: PlayerStats): void => {
    try {
      localStorage.setItem(STORAGE_KEYS.STATS, JSON.stringify(stats));
    } catch {}
  },

  // History
  getHistory: (): HistoryRecord[] => {
    try {
      const val = localStorage.getItem(STORAGE_KEYS.HISTORY);
      return val ? JSON.parse(val) : [];
    } catch {
      return [];
    }
  },

  addHistoryRecord: (record: HistoryRecord): void => {
    try {
      const history = storage.getHistory();
      history.unshift(record);
      // Keep last 50
      if (history.length > 50) history.pop();
      localStorage.setItem(STORAGE_KEYS.HISTORY, JSON.stringify(history));
    } catch {}
  },

  // Reset progress
  resetData: (): void => {
    try {
      localStorage.removeItem(STORAGE_KEYS.CASH);
      localStorage.removeItem(STORAGE_KEYS.STATS);
      localStorage.removeItem(STORAGE_KEYS.HISTORY);
    } catch {}
  },
};
