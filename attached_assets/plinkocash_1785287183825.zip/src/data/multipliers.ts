import { RiskLevel, MultiplierBucket } from '../types';

export interface BucketItem {
  label: string;
  multiplier: number;
  type: 'number' | 'zonk' | 'ads';
  color: string;
}

// User requested exact sequence:
// 5, 10, 20, ZONK, 25, 50, ADS, 75, 100, ADS, 125, ADS, 150, ZONK, 25, ADS, 20, 10, 5
export const CUSTOM_PLINKO_BUCKETS: BucketItem[] = [
  { label: '5x', multiplier: 5, type: 'number', color: '#eab308' },
  { label: '10x', multiplier: 10, type: 'number', color: '#ea580c' },
  { label: '20x', multiplier: 20, type: 'number', color: '#ea580c' },
  { label: 'ZONK', multiplier: 0, type: 'zonk', color: '#ef4444' },
  { label: '25x', multiplier: 25, type: 'number', color: '#f97316' },
  { label: '50x', multiplier: 50, type: 'number', color: '#dc2626' },
  { label: 'ADS', multiplier: 30, type: 'ads', color: '#8b5cf6' },
  { label: '75x', multiplier: 75, type: 'number', color: '#b91c1c' },
  { label: '100x', multiplier: 100, type: 'number', color: '#991b1b' },
  { label: 'ADS', multiplier: 50, type: 'ads', color: '#8b5cf6' },
  { label: '125x', multiplier: 125, type: 'number', color: '#7f1d1d' },
  { label: 'ADS', multiplier: 50, type: 'ads', color: '#8b5cf6' },
  { label: '150x', multiplier: 150, type: 'number', color: '#fbbf24' },
  { label: 'ZONK', multiplier: 0, type: 'zonk', color: '#ef4444' },
  { label: '25x', multiplier: 25, type: 'number', color: '#f97316' },
  { label: 'ADS', multiplier: 30, type: 'ads', color: '#8b5cf6' },
  { label: '20x', multiplier: 20, type: 'number', color: '#ea580c' },
  { label: '10x', multiplier: 10, type: 'number', color: '#eab308' },
  { label: '5x', multiplier: 5, type: 'number', color: '#eab308' },
];

export function getCustomBuckets(canvasWidth: number): MultiplierBucket[] {
  const bucketCount = CUSTOM_PLINKO_BUCKETS.length;
  const bucketWidth = canvasWidth / bucketCount;

  return CUSTOM_PLINKO_BUCKETS.map((item, idx) => ({
    index: idx,
    x: idx * bucketWidth,
    width: bucketWidth,
    multiplier: item.multiplier,
    label: item.label,
    color: item.color,
    type: item.type,
  }));
}

// Fallback multiplier generator for scaled row counts if needed
export function getBucketMultipliers(rows: number, risk: RiskLevel): number[] {
  return CUSTOM_PLINKO_BUCKETS.map((b) => b.multiplier);
}

export function getBucketColor(multiplier: number): { bg: string; text: string; glow: string } {
  if (multiplier >= 100) {
    return { bg: '#dc2626', text: '#ffffff', glow: 'rgba(220, 38, 38, 0.8)' };
  } else if (multiplier >= 25) {
    return { bg: '#ea580c', text: '#ffffff', glow: 'rgba(234, 88, 12, 0.8)' };
  } else if (multiplier >= 5) {
    return { bg: '#eab308', text: '#000000', glow: 'rgba(234, 179, 8, 0.8)' };
  } else {
    return { bg: '#ef4444', text: '#ffffff', glow: 'rgba(239, 68, 68, 0.6)' };
  }
}
