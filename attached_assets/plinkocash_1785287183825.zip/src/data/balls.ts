import { BallInfo } from '../types';

export const BALL_TYPES: BallInfo[] = [
  {
    id: 'standard',
    name: 'Standard Cash Ball',
    nameId: 'Bola Kas Standar',
    description: 'Classic heavy cash ball with standard physics.',
    descriptionId: 'Bola kas klasik dengan fisika standar.',
    costMultiplier: 1.0,
    color: '#38bdf8', // Sky blue
    glowColor: 'rgba(56, 189, 248, 0.8)',
    icon: 'Circle',
    unlocked: true,
  },
  {
    id: 'golden',
    name: 'Golden Double Ball',
    nameId: 'Bola Emas Ganda',
    description: 'Doubles all bucket multipliers on payout (2x Payout)!',
    descriptionId: 'Menggandakan semua multiplier bucket saat mendarat (Payout 2x)!',
    costMultiplier: 1.5,
    color: '#fbbf24', // Amber gold
    glowColor: 'rgba(251, 191, 36, 0.9)',
    icon: 'Sparkles',
    unlocked: true,
  },
  {
    id: 'splitter',
    name: 'Multi-Splitter Ball',
    nameId: 'Bola Multi-Pembagi',
    description: 'Splits into 3 mini balls halfway down for triple chances!',
    descriptionId: 'Pecah menjadi 3 bola kecil di pertengahan lintasan untuk 3x kesempatan!',
    costMultiplier: 2.0,
    color: '#c084fc', // Purple
    glowColor: 'rgba(192, 132, 252, 0.8)',
    icon: 'GitFork',
    unlocked: true,
  },
  {
    id: 'bomb',
    name: 'Explosive Bomb Ball',
    nameId: 'Bola Bom Peledak',
    description: 'Creates shockwaves on peg impact, bumping balls and lighting bonus pegs.',
    descriptionId: 'Menciptakan gelombang kejut saat menabrak pasak, mendorong bola lain.',
    costMultiplier: 2.5,
    color: '#ef4444', // Red
    glowColor: 'rgba(239, 68, 68, 0.9)',
    icon: 'Zap',
    unlocked: true,
  },
  {
    id: 'magnet',
    name: 'Lucky Magnet Ball',
    nameId: 'Bola Magnet Keberuntungan',
    description: 'Gently shifts towards high multiplier outer buckets.',
    descriptionId: 'Secara halus tertarik menuju bucket multiplier tinggi di sisi luar.',
    costMultiplier: 3.0,
    color: '#10b981', // Emerald
    glowColor: 'rgba(16, 185, 129, 0.9)',
    icon: 'Magnet',
    unlocked: true,
  },
];
