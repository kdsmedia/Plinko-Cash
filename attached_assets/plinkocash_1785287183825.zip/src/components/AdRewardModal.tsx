import React, { useState, useEffect } from 'react';
import { GameSettings } from '../types';
import { X, Play, CheckCircle, Sparkles, Tv, Coins, ArrowRight, AlertCircle } from 'lucide-react';
import { soundManager } from '../utils/audio';

interface AdRewardModalProps {
  isOpen: boolean;
  onClose: () => void;
  onClaimBalls: (count: number) => void;
  cash: number;
  onExchangePoints: (pointsDeducted: number, ballsGained: number) => void;
  settings: GameSettings;
}

export const AdRewardModal: React.FC<AdRewardModalProps> = ({
  isOpen,
  onClose,
  onClaimBalls,
  cash,
  onExchangePoints,
  settings,
}) => {
  const [activeTab, setActiveTab] = useState<'ad' | 'exchange'>('ad');
  const [countdown, setCountdown] = useState(5);
  const [isCompleted, setIsCompleted] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [exchangeBallsCount, setExchangeBallsCount] = useState<number>(1);
  const [exchangeMsg, setExchangeMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const isIndo = settings.language === 'id';

  useEffect(() => {
    if (!isOpen) {
      setCountdown(5);
      setIsCompleted(false);
      setIsPlaying(false);
      setExchangeMsg(null);
      return;
    }

    if (activeTab === 'ad') {
      setIsPlaying(true);
      setCountdown(5);
      setIsCompleted(false);

      const timer = setInterval(() => {
        setCountdown((prev) => {
          if (prev <= 1) {
            clearInterval(timer);
            setIsCompleted(true);
            setIsPlaying(false);
            soundManager.playWinSound();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);

      return () => clearInterval(timer);
    }
  }, [isOpen, activeTab]);

  if (!isOpen) return null;

  const handleClaimAd = () => {
    onClaimBalls(2); // Grant +2 balls
    soundManager.playWinSound();
    onClose();
  };

  const handleExchange = () => {
    setExchangeMsg(null);
    const requiredPoints = exchangeBallsCount * 50;

    if (cash < requiredPoints) {
      setExchangeMsg({
        type: 'error',
        text: isIndo
          ? `Poin/Saldo tidak cukup! Butuh ${requiredPoints.toLocaleString()} poin.`
          : `Insufficient points! Need ${requiredPoints.toLocaleString()} points.`,
      });
      return;
    }

    onExchangePoints(requiredPoints, exchangeBallsCount);
    soundManager.playWinSound();
    setExchangeMsg({
      type: 'success',
      text: isIndo
        ? `Berhasil menukar ${requiredPoints.toLocaleString()} poin dengan +${exchangeBallsCount} bola!`
        : `Successfully exchanged ${requiredPoints.toLocaleString()} points for +${exchangeBallsCount} balls!`,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/90 backdrop-blur-md animate-fadeIn select-none">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 max-w-sm w-full text-white shadow-2xl relative flex flex-col items-center">
        {/* Header */}
        <div className="w-full flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
              <Sparkles className="w-4 h-4" />
            </div>
            <span className="text-xs font-black text-amber-300">
              {isIndo ? 'Dapatkan Bola Gratis' : 'Get Free Balls'}
            </span>
          </div>

          {/* Close button */}
          <button
            onClick={onClose}
            disabled={activeTab === 'ad' && isPlaying}
            className={`p-1.5 rounded-xl border transition-all ${
              activeTab === 'ad' && isPlaying
                ? 'bg-slate-950 text-slate-600 border-slate-800 opacity-50 cursor-not-allowed'
                : 'bg-slate-800 hover:bg-slate-700 text-white border-slate-700'
            }`}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="grid grid-cols-2 gap-1.5 p-1 bg-slate-950 rounded-2xl border border-slate-800 w-full my-3">
          <button
            onClick={() => setActiveTab('ad')}
            className={`py-2 px-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'ad'
                ? 'bg-amber-500 text-slate-950 font-black shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Tv className="w-3.5 h-3.5" />
            <span>{isIndo ? 'Iklan (+2 Bola)' : 'Watch Ad (+2)'}</span>
          </button>

          <button
            onClick={() => setActiveTab('exchange')}
            className={`py-2 px-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'exchange'
                ? 'bg-cyan-500 text-slate-950 font-black shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Coins className="w-3.5 h-3.5" />
            <span>{isIndo ? 'Tukar Poin' : 'Exchange Points'}</span>
          </button>
        </div>

        {/* Tab 1: Watch Ad (+2 Balls) */}
        {activeTab === 'ad' && (
          <div className="w-full flex flex-col items-center animate-fadeIn">
            {/* Video Simulation Screen */}
            <div className="relative w-full aspect-video bg-slate-950 rounded-2xl border border-slate-800 mb-3 overflow-hidden flex flex-col items-center justify-center p-4 text-center">
              <div className="absolute inset-0 bg-gradient-to-tr from-amber-500/10 via-purple-500/10 to-indigo-500/10 animate-pulse"></div>

              {isPlaying && (
                <div className="relative z-10 flex flex-col items-center gap-2">
                  <div className="w-10 h-10 rounded-full bg-amber-500/20 border border-amber-400/40 text-amber-300 flex items-center justify-center animate-spin-slow">
                    <Play className="w-5 h-5 fill-amber-300 ml-0.5" />
                  </div>
                  <div className="text-xs font-black text-slate-200">
                    {isIndo ? 'Menonton Iklan Game...' : 'Watching Game Ad...'}
                  </div>
                  <div className="px-3 py-1 rounded-full bg-slate-900/90 border border-amber-500/40 text-amber-400 text-xs font-mono font-black">
                    {isIndo ? `Sisa Waktu: ${countdown} d` : `Time Left: ${countdown}s`}
                  </div>
                  <p className="text-[10px] text-slate-500 italic mt-0.5">
                    {isIndo ? 'Dapatkan +2 bola setelah iklan selesai' : 'Get +2 balls after ad finishes'}
                  </p>
                </div>
              )}

              {isCompleted && (
                <div className="relative z-10 flex flex-col items-center gap-1.5 animate-bounce">
                  <div className="w-10 h-10 rounded-full bg-emerald-500/20 border border-emerald-400/40 text-emerald-400 flex items-center justify-center">
                    <CheckCircle className="w-6 h-6" />
                  </div>
                  <div className="text-xs font-black text-emerald-400">
                    {isIndo ? 'Iklan Selesai Ditonton!' : 'Ad Complete!'}
                  </div>
                  <p className="text-xs text-slate-300 font-bold">
                    {isIndo ? 'Siap Klaim +2 Bola Gratis' : 'Ready to Claim +2 Free Balls'}
                  </p>
                </div>
              )}
            </div>

            {/* Claim Action Button */}
            <button
              onClick={handleClaimAd}
              disabled={!isCompleted}
              className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 text-slate-950 font-black text-xs sm:text-sm uppercase tracking-wider shadow-lg shadow-amber-500/20 hover:brightness-110 active:scale-95 transition-all flex items-center justify-center gap-2 disabled:opacity-40 disabled:cursor-not-allowed touch-manipulation"
            >
              <Sparkles className="w-4 h-4 fill-slate-950" />
              <span>{isCompleted ? (isIndo ? 'KLAIM +2 BOLA GRATIS' : 'CLAIM +2 FREE BALLS') : (isIndo ? 'TUNGGU IKLAN SELESAI' : 'WAIT FOR AD')}</span>
            </button>
          </div>
        )}

        {/* Tab 2: Exchange Points (50 Points = 1 Ball) */}
        {activeTab === 'exchange' && (
          <div className="w-full flex flex-col gap-3 animate-fadeIn">
            {/* Current Balance & Rate Info */}
            <div className="bg-slate-950 border border-cyan-500/30 rounded-2xl p-3 flex items-center justify-between">
              <div>
                <span className="text-[10px] text-slate-400 font-bold uppercase block">
                  {isIndo ? 'Saldo Poin Anda' : 'Your Points Balance'}
                </span>
                <span className="text-cyan-300 font-black text-sm font-mono">
                  {cash.toLocaleString()} Poin (Rp)
                </span>
              </div>
              <div className="bg-cyan-500/20 border border-cyan-500/40 px-2 py-1 rounded-xl text-[10px] font-black text-cyan-400">
                50 Poin = 1 Bola
              </div>
            </div>

            {/* Select Balls Quantity Preset */}
            <div className="flex flex-col gap-1.5">
              <label className="text-[11px] font-bold text-slate-300">
                {isIndo ? 'Pilih Jumlah Bola:' : 'Select Balls Amount:'}
              </label>
              <div className="grid grid-cols-4 gap-1.5">
                {[1, 5, 10, 20].map((num) => {
                  const cost = num * 50;
                  const isSelected = exchangeBallsCount === num;

                  return (
                    <button
                      key={num}
                      onClick={() => setExchangeBallsCount(num)}
                      className={`py-2 px-1 rounded-xl text-center transition-all border ${
                        isSelected
                          ? 'bg-cyan-500 text-slate-950 border-cyan-300 font-black shadow-md'
                          : 'bg-slate-950 text-slate-300 border-slate-800 hover:border-slate-700 font-bold'
                      }`}
                    >
                      <div className="text-xs">{num} Bola</div>
                      <div className="text-[9px] opacity-80">{cost} P</div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Total Cost Display */}
            <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex items-center justify-between text-xs">
              <span className="text-slate-400 font-medium">
                {isIndo ? 'Total Poin Dibutuhkan:' : 'Total Points Required:'}
              </span>
              <span className="text-amber-400 font-black font-mono text-sm">
                {(exchangeBallsCount * 50).toLocaleString()} Poin
              </span>
            </div>

            {/* Exchange Status Messages */}
            {exchangeMsg && (
              <div
                className={`p-2 rounded-xl text-[11px] font-bold flex items-center gap-1.5 border ${
                  exchangeMsg.type === 'error'
                    ? 'bg-red-500/10 text-red-400 border-red-500/20'
                    : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                }`}
              >
                {exchangeMsg.type === 'error' ? (
                  <AlertCircle className="w-4 h-4 shrink-0" />
                ) : (
                  <CheckCircle className="w-4 h-4 shrink-0" />
                )}
                <span>{exchangeMsg.text}</span>
              </div>
            )}

            {/* Exchange Action Button */}
            <button
              onClick={handleExchange}
              className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-500 text-slate-950 font-black text-xs sm:text-sm uppercase tracking-wider shadow-lg shadow-cyan-500/20 hover:brightness-110 active:scale-95 transition-all flex items-center justify-center gap-2 touch-manipulation"
            >
              <span>{isIndo ? `TUKAR ${exchangeBallsCount * 50} POIN MET ${exchangeBallsCount} BOLA` : `EXCHANGE FOR ${exchangeBallsCount} BALLS`}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
