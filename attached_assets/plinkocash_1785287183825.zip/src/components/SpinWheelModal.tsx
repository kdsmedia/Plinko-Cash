import React, { useState } from 'react';
import { GameSettings } from '../types';
import { X, Sparkles, Trophy, Disc, Tv, AlertCircle, CheckCircle2 } from 'lucide-react';
import { soundManager } from '../utils/audio';

interface PrizeSegment {
  id: number;
  label: string;
  type: 'cash' | 'balls' | 'zonk';
  value: number;
  color: string;
  textColor: string;
  weight: number; // Higher weight = higher chance to land
}

const SEGMENTS: PrizeSegment[] = [
  { id: 1, label: '+1 Bola', type: 'balls', value: 1, color: '#f59e0b', textColor: '#ffffff', weight: 12 },
  { id: 2, label: 'Rp 100', type: 'cash', value: 100, color: '#10b981', textColor: '#ffffff', weight: 12 },
  { id: 3, label: 'Zonk', type: 'zonk', value: 0, color: '#64748b', textColor: '#ffffff', weight: 30 },
  { id: 4, label: 'Rp 200', type: 'cash', value: 200, color: '#3b82f6', textColor: '#ffffff', weight: 5 },
  { id: 5, label: '+2 Bola', type: 'balls', value: 2, color: '#ec4899', textColor: '#ffffff', weight: 4 },
  { id: 6, label: 'Zonk', type: 'zonk', value: 0, color: '#475569', textColor: '#ffffff', weight: 25 },
  { id: 7, label: 'Rp 250', type: 'cash', value: 250, color: '#8b5cf6', textColor: '#ffffff', weight: 2 },
  { id: 8, label: '+3 Bola', type: 'balls', value: 3, color: '#f97316', textColor: '#ffffff', weight: 2 },
  { id: 9, label: 'Rp 50', type: 'cash', value: 50, color: '#06b6d4', textColor: '#ffffff', weight: 15 },
  { id: 10, label: '+1 Bola', type: 'balls', value: 1, color: '#eab308', textColor: '#0f172a', weight: 12 },
];

interface SpinWheelModalProps {
  isOpen: boolean;
  onClose: () => void;
  onWinPrize: (type: 'cash' | 'balls', value: number) => void;
  onOpenAdReward?: () => void;
  settings: GameSettings;
}

export const SpinWheelModal: React.FC<SpinWheelModalProps> = ({
  isOpen,
  onClose,
  onWinPrize,
  onOpenAdReward,
  settings,
}) => {
  const [isSpinning, setIsSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [wonPrize, setWonPrize] = useState<PrizeSegment | null>(null);
  const [showResultPopup, setShowResultPopup] = useState(false);
  const isIndo = settings.language === 'id';

  if (!isOpen) return null;

  // Weighted random algorithm favoring Zonk & small amounts
  const getWeightedWinningIndex = (): number => {
    const totalWeight = SEGMENTS.reduce((sum, seg) => sum + seg.weight, 0);
    let randomNum = Math.random() * totalWeight;

    for (let i = 0; i < SEGMENTS.length; i++) {
      if (randomNum < SEGMENTS[i].weight) {
        return i;
      }
      randomNum -= SEGMENTS[i].weight;
    }
    return 2; // Default to Zonk
  };

  const handleSpin = () => {
    if (isSpinning) return;

    setIsSpinning(true);
    setWonPrize(null);
    setShowResultPopup(false);
    soundManager.playButtonClick();

    // Calculate target segment based on realistic weighted odds
    const winningIndex = getWeightedWinningIndex();
    const segmentAngle = 360 / SEGMENTS.length; // 36 degrees per segment
    
    // Realistic long spin: 10 to 14 full rotations (3600 to 5040 degrees)
    const fullSpins = (10 + Math.floor(Math.random() * 5)) * 360;
    // Calculate final angle to align top pointer arrow (270 deg / top center)
    const targetSegmentAngle = winningIndex * segmentAngle + segmentAngle / 2;
    const finalRotation = rotation + fullSpins + (360 - (rotation % 360)) + (360 - targetSegmentAngle);

    setRotation(finalRotation);

    // Realistic slow deceleration spin (6.0 seconds duration)
    setTimeout(() => {
      setIsSpinning(false);
      const prize = SEGMENTS[winningIndex];
      setWonPrize(prize);
      setShowResultPopup(true);

      if (prize.type !== 'zonk' && prize.value > 0) {
        soundManager.playWinSound();
      } else {
        soundManager.playZonkSound();
      }
    }, 6000);
  };

  const handleConfirmResultAndAd = () => {
    if (wonPrize && wonPrize.type !== 'zonk' && wonPrize.value > 0) {
      onWinPrize(wonPrize.type, wonPrize.value);
    }
    setShowResultPopup(false);
    onClose();

    // Trigger Ad Reward Modal
    if (onOpenAdReward) {
      setTimeout(() => {
        onOpenAdReward();
      }, 300);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/80 backdrop-blur-md animate-fadeIn select-none">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 max-w-sm w-full text-white shadow-2xl relative flex flex-col items-center">
        {/* Close Button */}
        <button
          onClick={onClose}
          disabled={isSpinning}
          className="absolute top-4 right-4 p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-all disabled:opacity-40"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-2 mb-2">
          <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
            <Disc className="w-5 h-5 animate-spin-slow" />
          </div>
          <div>
            <h2 className="text-base font-black text-amber-300">
              {isIndo ? 'Roda Keberuntungan Spin Wheel' : 'Lucky Spin Wheel'}
            </h2>
            <p className="text-[10px] text-slate-400">
              {isIndo ? 'Putar roda realistis untuk klaim hadiah!' : 'Realistic spin wheel for free rewards!'}
            </p>
          </div>
        </div>

        {/* Wheel Container */}
        <div className="relative my-3 w-64 h-64 flex items-center justify-center">
          {/* Top Pointer Arrow */}
          <div className="absolute -top-3 z-20 w-0 h-0 border-l-[12px] border-l-transparent border-r-[12px] border-r-transparent border-t-[20px] border-t-amber-400 filter drop-shadow-md"></div>

          {/* Rotating Wheel Circle */}
          <div
            className="w-full h-full rounded-full border-4 border-amber-400/80 shadow-2xl overflow-hidden relative"
            style={{
              transform: `rotate(${rotation}deg)`,
              transition: isSpinning ? 'transform 6s cubic-bezier(0.12, 0.8, 0.15, 1.0)' : 'none',
            }}
          >
            {/* SVG Segments */}
            <svg viewBox="0 0 100 100" className="w-full h-full transform -rotate-90">
              {SEGMENTS.map((seg, idx) => {
                const angle = 360 / SEGMENTS.length;
                const startAngle = idx * angle;
                const endAngle = (idx + 1) * angle;

                const x1 = 50 + 50 * Math.cos((Math.PI * startAngle) / 180);
                const y1 = 50 + 50 * Math.sin((Math.PI * startAngle) / 180);
                const x2 = 50 + 50 * Math.cos((Math.PI * endAngle) / 180);
                const y2 = 50 + 50 * Math.sin((Math.PI * endAngle) / 180);

                const pathData = `M 50 50 L ${x1} ${y1} A 50 50 0 0 1 ${x2} ${y2} Z`;

                // Label angle calculation
                const midAngle = startAngle + angle / 2;
                const labelX = 50 + 34 * Math.cos((Math.PI * midAngle) / 180);
                const labelY = 50 + 34 * Math.sin((Math.PI * midAngle) / 180);

                return (
                  <g key={seg.id}>
                    <path d={pathData} fill={seg.color} stroke="#0f172a" strokeWidth="0.8" />
                    <text
                      x={labelX}
                      y={labelY}
                      fill={seg.textColor}
                      fontSize="4"
                      fontWeight="900"
                      textAnchor="middle"
                      dominantBaseline="middle"
                      transform={`rotate(${midAngle + 90}, ${labelX}, ${labelY})`}
                    >
                      {seg.label}
                    </text>
                  </g>
                );
              })}
            </svg>

            {/* Wheel Center Badge */}
            <div className="absolute inset-0 m-auto w-12 h-12 rounded-full bg-slate-950 border-2 border-amber-400 flex items-center justify-center text-amber-400 shadow-lg z-10">
              <Sparkles className="w-6 h-6 animate-pulse" />
            </div>
          </div>
        </div>

        {/* Spin Action Button */}
        <button
          onClick={handleSpin}
          disabled={isSpinning}
          className="w-full mt-2 py-3.5 px-4 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 text-slate-950 font-black text-sm uppercase tracking-wider shadow-lg shadow-amber-500/20 hover:brightness-110 active:scale-95 transition-all flex items-center justify-center gap-2 disabled:opacity-50 touch-manipulation"
        >
          <Trophy className="w-5 h-5 fill-slate-950" />
          <span>{isSpinning ? (isIndo ? 'Roda Sedang Berputar...' : 'Spinning Wheel...') : (isIndo ? 'PUTAR RODA SEKARANG' : 'SPIN WHEEL NOW')}</span>
        </button>
      </div>

      {/* Prize Result Popup Overlay with OK Button (Triggers Ad) */}
      {showResultPopup && wonPrize && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-lg animate-fadeIn">
          <div className="bg-slate-900 border-2 border-amber-500/60 rounded-3xl p-6 max-w-xs w-full text-white shadow-2xl text-center flex flex-col items-center gap-3 animate-scaleUp">
            {/* Visual Icon Header */}
            {wonPrize.type === 'zonk' ? (
              <div className="w-16 h-16 rounded-full bg-slate-800 border-2 border-slate-700 text-slate-400 flex items-center justify-center shadow-lg">
                <AlertCircle className="w-10 h-10" />
              </div>
            ) : (
              <div className="w-16 h-16 rounded-full bg-amber-500/20 border-2 border-amber-400 text-amber-300 flex items-center justify-center shadow-lg animate-bounce">
                <CheckCircle2 className="w-10 h-10" />
              </div>
            )}

            <div>
              <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">
                {isIndo ? 'Pernyataan Hasil Spin' : 'Spin Wheel Statement'}
              </span>
              <h3 className="text-xl font-black text-amber-300 mt-0.5">
                {wonPrize.type === 'zonk'
                  ? (isIndo ? 'SAYANG SEKALI ZONK!' : 'BAD LUCK ZONK!')
                  : (isIndo ? 'SELAMAT ANDA MENANG!' : 'CONGRATULATIONS!')}
              </h3>
            </div>

            <div className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-3 my-1">
              <div className="text-xs text-slate-400 font-medium">
                {isIndo ? 'Hadiah Yang Didapat:' : 'Prize Earned:'}
              </div>
              <div className="text-2xl font-black text-emerald-400 mt-0.5">
                {wonPrize.label}
              </div>
            </div>

            <p className="text-[11px] text-slate-400 leading-relaxed">
              {isIndo
                ? 'Tekan tombol OK untuk klaim hadiah dan tonton iklan sponsored.'
                : 'Press OK button to claim reward and watch sponsored ad.'}
            </p>

            <button
              onClick={handleConfirmResultAndAd}
              className="w-full mt-2 py-3 px-4 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-500 text-slate-950 font-black text-sm uppercase tracking-wider shadow-lg shadow-emerald-500/25 hover:brightness-110 active:scale-95 transition-all flex items-center justify-center gap-2 touch-manipulation"
            >
              <Tv className="w-4 h-4 fill-slate-950" />
              <span>OK ({isIndo ? 'TONTON IKLAN' : 'WATCH AD'})</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

