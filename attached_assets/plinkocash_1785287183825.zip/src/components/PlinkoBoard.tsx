import React, { useEffect, useRef, useCallback } from 'react';
import { Ball, Peg, MultiplierBucket, Particle, BallType, RiskLevel, GameSettings } from '../types';
import { getBucketColor, getCustomBuckets } from '../data/multipliers';
import { soundManager } from '../utils/audio';
import confetti from 'canvas-confetti';

interface PlinkoBoardProps {
  rows: number;
  risk?: RiskLevel;
  settings: GameSettings;
  onBallLanded: (payout: number, multiplier: number, ballType: BallType, goldenPegsHit: number) => void;
  onDropRef?: React.MutableRefObject<((type: BallType, bet: number) => void) | null>;
}

export const PlinkoBoard: React.FC<PlinkoBoardProps> = ({
  rows,
  risk = 'high',
  settings,
  onBallLanded,
  onDropRef,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Mutable refs for physics state
  const ballsRef = useRef<Ball[]>([]);
  const pegsRef = useRef<Peg[]>([]);
  const bucketsRef = useRef<MultiplierBucket[]>([]);
  const particlesRef = useRef<Particle[]>([]);
  const goldenPegHitsRef = useRef<Map<string, number>>(new Map()); // ballId -> golden count

  const animFrameIdRef = useRef<number | null>(null);

  // Canvas size and padding constants
  const CANVAS_WIDTH = 640;
  const CANVAS_HEIGHT = 680;
  const PIN_RADIUS = 5;
  const BALL_RADIUS = 8;
  const TOP_PADDING = 70;
  const BOTTOM_PADDING = 80;

  // Initialize Board Pegs & Buckets layout
  const initBoard = useCallback(() => {
    const pegs: Peg[] = [];
    const boardHeight = CANVAS_HEIGHT - TOP_PADDING - BOTTOM_PADDING;
    const rowHeight = boardHeight / (rows + 1);

    const buckets: MultiplierBucket[] = getCustomBuckets(CANVAS_WIDTH);
    const totalBuckets = buckets.length;

    for (let r = 0; r < rows; r++) {
      const progress = r / Math.max(1, rows - 1);
      const pinCount = Math.round(3 + progress * (totalBuckets - 2));
      const rowY = TOP_PADDING + (r + 1) * rowHeight;

      // Calculate horizontal spread
      const maxPins = totalBuckets + 1;
      const spacing = CANVAS_WIDTH / maxPins;
      const startX = (CANVAS_WIDTH - (pinCount - 1) * spacing) / 2;

      for (let c = 0; c < pinCount; c++) {
        const x = startX + c * spacing;
        // 12% chance for golden pin
        const isGolden = (r + c) % 7 === 0 || Math.random() < 0.12;

        pegs.push({
          x,
          y: rowY,
          radius: PIN_RADIUS,
          isGolden,
          hitCount: 0,
          valueBonus: isGolden ? 50 : 0,
        });
      }
    }
    pegsRef.current = pegs;
    bucketsRef.current = buckets;
  }, [rows, risk]);

  // Drop a new ball into the physics simulation
  const dropBall = useCallback(
    (type: BallType, betAmount: number) => {
      soundManager.playDropSound();

      // Top drop point with micro horizontal perturbation
      const startX = CANVAS_WIDTH / 2 + (Math.random() * 8 - 4);
      const startY = TOP_PADDING - 25;

      let color = '#38bdf8';
      if (type === 'golden') color = '#fbbf24';
      if (type === 'splitter') color = '#c084fc';
      if (type === 'bomb') color = '#ef4444';
      if (type === 'magnet') color = '#10b981';

      const newBall: Ball = {
        id: `ball_${Date.now()}_${Math.random()}`,
        type,
        x: startX,
        y: startY,
        vx: (Math.random() - 0.5) * 0.8,
        vy: 0.3 + Math.random() * 0.2,
        radius: BALL_RADIUS,
        color,
        betAmount,
        isGolden: type === 'golden',
        isSplitter: type === 'splitter',
        hasSplit: false,
        trail: [],
      };

      ballsRef.current.push(newBall);
      goldenPegHitsRef.current.set(newBall.id, 0);
    },
    []
  );

  // Bind drop function to ref for parent invocation
  useEffect(() => {
    if (onDropRef) {
      onDropRef.current = dropBall;
    }
  }, [dropBall, onDropRef]);

  // Re-initialize when rows or risk change
  useEffect(() => {
    initBoard();
  }, [initBoard]);

  // Particle explosion helper
  const spawnParticles = (x: number, y: number, color: string, count: number = 10, text?: string) => {
    const newParticles: Particle[] = [];
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 1 + Math.random() * 4;
      newParticles.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - 1,
        color,
        radius: 2 + Math.random() * 3,
        alpha: 1,
        life: 0,
        maxLife: 20 + Math.random() * 20,
        text: i === 0 ? text : undefined,
      });
    }
    particlesRef.current.push(...newParticles);
  };

  // Main Render & Physics Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let running = true;

    const render = () => {
      if (!running) return;

      // Clear Canvas
      ctx.fillStyle = '#0a0f1d';
      ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

      // Draw subtle background grid lines
      ctx.strokeStyle = '#1e293b22';
      ctx.lineWidth = 1;
      for (let x = 0; x < CANVAS_WIDTH; x += 40) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, CANVAS_HEIGHT);
        ctx.stroke();
      }

      // Draw Pegs
      const pegs = pegsRef.current;
      const now = Date.now();

      pegs.forEach((peg) => {
        ctx.save();
        ctx.beginPath();
        ctx.arc(peg.x, peg.y, peg.radius, 0, Math.PI * 2);

        // Check recent hit highlight
        const isRecentlyHit = peg.hitTime && now - peg.hitTime < 250;

        if (peg.isGolden) {
          ctx.fillStyle = isRecentlyHit ? '#ffffff' : '#fbbf24';
          ctx.shadowColor = '#fbbf24';
          ctx.shadowBlur = isRecentlyHit ? 15 : 8;
        } else {
          ctx.fillStyle = isRecentlyHit ? '#38bdf8' : '#64748b';
          ctx.shadowColor = '#38bdf8';
          ctx.shadowBlur = isRecentlyHit ? 12 : 0;
        }

        ctx.fill();
        ctx.restore();
      });

      // Update & Draw Balls
      const balls = ballsRef.current;
      const nextBalls: Ball[] = [];
      const buckets = bucketsRef.current;
      const bucketY = CANVAS_HEIGHT - BOTTOM_PADDING;

      for (let i = 0; i < balls.length; i++) {
        const ball = balls[i];

        // Apply Natural Gentle Gravity & Friction
        ball.vy += 0.11;
        ball.vx *= 0.985;
        ball.vy *= 0.985;

        // Velocity Clamp for smooth controlled descent
        const speed = Math.hypot(ball.vx, ball.vy);
        if (speed > 5.5) {
          ball.vx = (ball.vx / speed) * 5.5;
          ball.vy = (ball.vy / speed) * 5.5;
        }

        // Magnet Ball Special Steering Logic
        if (ball.type === 'magnet') {
          // Magnet pulls towards outer jackpot buckets
          const center = CANVAS_WIDTH / 2;
          const pull = ball.x < center ? -0.08 : 0.08;
          ball.vx += pull;
        }

        // Update Position
        ball.x += ball.vx;
        ball.y += ball.vy;

        // Trail points
        ball.trail.push({ x: ball.x, y: ball.y, alpha: 1 });
        if (ball.trail.length > 8) ball.trail.shift();

        // Draw Trail
        ball.trail.forEach((t, idx) => {
          ctx.beginPath();
          ctx.arc(t.x, t.y, ball.radius * (idx / ball.trail.length), 0, Math.PI * 2);
          ctx.fillStyle = ball.color;
          ctx.globalAlpha = (idx / ball.trail.length) * 0.3;
          ctx.fill();
          ctx.globalAlpha = 1;
        });

        // Wall collisions
        if (ball.x - ball.radius < 10) {
          ball.x = 10 + ball.radius;
          ball.vx = Math.abs(ball.vx) * 0.7;
        } else if (ball.x + ball.radius > CANVAS_WIDTH - 10) {
          ball.x = CANVAS_WIDTH - 10 - ball.radius;
          ball.vx = -Math.abs(ball.vx) * 0.7;
        }

        // Peg collision detection
        for (let p = 0; p < pegs.length; p++) {
          const peg = pegs[p];
          const dx = ball.x - peg.x;
          const dy = ball.y - peg.y;
          const dist = Math.hypot(dx, dy);
          const minDist = ball.radius + peg.radius;

          if (dist < minDist) {
            // Normal vector
            const nx = dx / (dist || 1);
            const ny = dy / (dist || 1);

            // Positional correction
            ball.x = peg.x + nx * minDist;
            ball.y = peg.y + ny * minDist;

            // Velocity bounce reflection with realistic damping
            const dot = ball.vx * nx + ball.vy * ny;
            const restitution = 0.55;

            ball.vx = (ball.vx - (1 + restitution) * dot * nx) + (Math.random() - 0.5) * 0.35;
            ball.vy = (ball.vy - (1 + restitution) * dot * ny) + (Math.random() - 0.5) * 0.15;

            peg.hitTime = now;
            peg.hitCount = (peg.hitCount || 0) + 1;

            // Sound chime
            const rowRatio = (peg.y - TOP_PADDING) / (CANVAS_HEIGHT - TOP_PADDING - BOTTOM_PADDING);
            soundManager.playPegChime(rowRatio, peg.isGolden);

            // Golden peg hit
            if (peg.isGolden) {
              const currentHits = goldenPegHitsRef.current.get(ball.id) || 0;
              goldenPegHitsRef.current.set(ball.id, currentHits + 1);
              spawnParticles(peg.x, peg.y, '#fbbf24', 6, '+$50');
            }

            // Bomb ball explosion shockwave
            if (ball.type === 'bomb') {
              soundManager.playBombSound();
              spawnParticles(peg.x, peg.y, '#ef4444', 12);
              // Push nearby balls
              for (let bOther = 0; bOther < balls.length; bOther++) {
                if (bOther !== i) {
                  const ob = balls[bOther];
                  const bdx = ob.x - peg.x;
                  const bdy = ob.y - peg.y;
                  const bdist = Math.hypot(bdx, bdy);
                  if (bdist < 60) {
                    ob.vx += (bdx / (bdist || 1)) * 3;
                    ob.vy += (bdy / (bdist || 1)) * 3;
                  }
                }
              }
            }
            break;
          }
        }

        // Splitter ball logic (split at 45% height)
        if (
          ball.type === 'splitter' &&
          !ball.hasSplit &&
          ball.y > TOP_PADDING + (CANVAS_HEIGHT - TOP_PADDING - BOTTOM_PADDING) * 0.45
        ) {
          ball.hasSplit = true;
          spawnParticles(ball.x, ball.y, '#c084fc', 10, 'SPLIT!');

          // Spawn 2 mini split balls
          const split1: Ball = {
            ...ball,
            id: `ball_split1_${Date.now()}_${Math.random()}`,
            vx: ball.vx - 1.8,
            vy: ball.vy * 0.9,
            radius: BALL_RADIUS * 0.85,
          };
          const split2: Ball = {
            ...ball,
            id: `ball_split2_${Date.now()}_${Math.random()}`,
            vx: ball.vx + 1.8,
            vy: ball.vy * 0.9,
            radius: BALL_RADIUS * 0.85,
          };
          nextBalls.push(split1, split2);
        }

        // Multiplier Bucket landing check
        if (ball.y + ball.radius >= bucketY) {
          const bucketWidth = CANVAS_WIDTH / buckets.length;
          const bucketIdx = Math.min(
            buckets.length - 1,
            Math.max(0, Math.floor(ball.x / bucketWidth))
          );
          const landingBucket = buckets[bucketIdx];

          landingBucket.highlightTime = now;

          // Payout calculation
          let multiplier = landingBucket.multiplier;
          if (ball.isGolden) multiplier *= 2; // Golden ball 2x payout bonus!

          const goldenCount = goldenPegHitsRef.current.get(ball.id) || 0;
          const instantBonus = goldenCount * 50;
          const payout = ball.betAmount * multiplier + instantBonus;

          // Sound & confetti effects
          if (landingBucket.type === 'zonk') {
            soundManager.playZonkSound();
          } else if (landingBucket.type === 'ads') {
            soundManager.playAdsSound();
            confetti({
              particleCount: 25,
              spread: 50,
              origin: { y: 0.85 },
            });
          } else {
            soundManager.playBucketWin(multiplier);
            if (multiplier >= 25) {
              confetti({
                particleCount: 40,
                spread: 60,
                origin: { y: 0.85 },
              });
            }
          }

          let particleText = `${multiplier}x`;
          if (landingBucket.type === 'zonk') {
            particleText = 'ZONK! 0x';
          } else if (landingBucket.type === 'ads') {
            particleText = 'ADS BONUS!';
          }

          spawnParticles(
            ball.x,
            bucketY,
            landingBucket.color,
            12,
            particleText
          );

          onBallLanded(payout, multiplier, ball.type, goldenCount);
          goldenPegHitsRef.current.delete(ball.id);
        } else {
          nextBalls.push(ball);
        }

        // Draw Ball
        ctx.save();
        ctx.beginPath();
        ctx.arc(ball.x, ball.y, ball.radius, 0, Math.PI * 2);
        ctx.fillStyle = ball.color;
        ctx.shadowColor = ball.color;
        ctx.shadowBlur = 10;
        ctx.fill();
        ctx.restore();
      }

      ballsRef.current = nextBalls;

      // Draw Multiplier Buckets at bottom
      buckets.forEach((b) => {
        const isHit = b.highlightTime && now - b.highlightTime < 300;

        ctx.save();
        ctx.fillStyle = isHit ? '#ffffff' : b.color;
        ctx.fillRect(b.x + 0.5, bucketY, b.width - 1, BOTTOM_PADDING - 10);

        // Border outline
        ctx.strokeStyle = isHit ? '#fbbf24' : '#0f172a';
        ctx.lineWidth = isHit ? 2 : 1;
        ctx.strokeRect(b.x + 0.5, bucketY, b.width - 1, BOTTOM_PADDING - 10);

        // Bucket Label
        ctx.fillStyle = isHit ? '#000000' : (b.type === 'ads' ? '#fef08a' : '#ffffff');

        let fontSize = '9.5px';
        if (b.label.length >= 4) {
          fontSize = '7.5px';
        } else if (b.label.length === 3) {
          fontSize = '8.5px';
        }

        ctx.font = `bold ${fontSize} system-ui, sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(b.label, b.x + b.width / 2, bucketY + (BOTTOM_PADDING - 10) / 2);
        ctx.restore();
      });

      // Update & Draw Particles
      const particles = particlesRef.current;
      const nextParticles: Particle[] = [];

      particles.forEach((p) => {
        p.life++;
        p.x += p.vx;
        p.y += p.vy;
        p.alpha = 1 - p.life / p.maxLife;

        if (p.life < p.maxLife) {
          ctx.save();
          if (p.text) {
            ctx.fillStyle = p.color;
            ctx.font = 'extrabold 12px system-ui';
            ctx.textAlign = 'center';
            ctx.globalAlpha = p.alpha;
            ctx.fillText(p.text, p.x, p.y);
          } else {
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
            ctx.fillStyle = p.color;
            ctx.globalAlpha = p.alpha;
            ctx.fill();
          }
          ctx.restore();
          nextParticles.push(p);
        }
      });
      particlesRef.current = nextParticles;

      animFrameIdRef.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      running = false;
      if (animFrameIdRef.current) cancelAnimationFrame(animFrameIdRef.current);
    };
  }, [rows, risk, onBallLanded]);

  return (
    <div id="plinko-canvas-container" className="relative w-full max-w-[640px] aspect-[640/680] mx-auto bg-slate-950 rounded-2xl border border-slate-800 shadow-2xl overflow-hidden flex items-center justify-center">
      <canvas
        ref={canvasRef}
        width={CANVAS_WIDTH}
        height={CANVAS_HEIGHT}
        className="w-full h-full object-contain cursor-crosshair"
      />
    </div>
  );
};
