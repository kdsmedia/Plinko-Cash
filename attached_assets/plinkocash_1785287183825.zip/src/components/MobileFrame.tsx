import React from 'react';
import { Wifi, Battery, Signal, Smartphone } from 'lucide-react';

interface MobileFrameProps {
  children: React.ReactNode;
  enabled: boolean;
}

export const MobileFrame: React.FC<MobileFrameProps> = ({ children, enabled }) => {
  if (!enabled) return <>{children}</>;

  return (
    <div id="mobile-frame-container" className="min-h-screen bg-slate-950 py-4 sm:py-8 flex items-center justify-center p-2 sm:p-4">
      <div className="w-full max-w-[420px] bg-slate-900 border-[8px] border-slate-800 rounded-[48px] shadow-2xl shadow-cyan-500/10 overflow-hidden relative flex flex-col min-h-[820px]">
        {/* Top iPhone Dynamic Island / Notch Bar */}
        <div className="w-full bg-slate-950 px-6 pt-3 pb-2 flex items-center justify-between text-[11px] font-bold text-slate-300 z-40 select-none border-b border-slate-800/50">
          <span>09:41</span>
          <div className="w-20 h-4 bg-slate-900 rounded-full flex items-center justify-center border border-slate-800">
            <div className="w-2 h-2 rounded-full bg-slate-800 mr-1" />
            <div className="w-1.5 h-1.5 rounded-full bg-blue-500" />
          </div>
          <div className="flex items-center gap-1.5">
            <Signal className="w-3 h-3" />
            <Wifi className="w-3 h-3" />
            <Battery className="w-3.5 h-3.5 fill-current" />
          </div>
        </div>

        {/* Content Viewport */}
        <div className="flex-1 overflow-y-auto scrollbar-none flex flex-col bg-slate-950">
          {children}
        </div>

        {/* Bottom Home Pill Bar */}
        <div className="w-full bg-slate-950 py-2.5 flex items-center justify-center z-40 border-t border-slate-900">
          <div className="w-32 h-1 bg-slate-700 rounded-full" />
        </div>
      </div>
    </div>
  );
};
