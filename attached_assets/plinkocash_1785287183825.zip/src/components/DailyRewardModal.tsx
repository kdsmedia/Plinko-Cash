import React, { useState } from 'react';
import { GameSettings } from '../types';
import { Gift, Sparkles, X, RotateCw } from 'lucide-react';
import confetti from 'canvas-confetti';

interface DailyRewardModalProps {
  isOpen: boolean;
  onClose: () => void;
  onClaimReward: (amount: number) => void;
  settings: GameSettings;
}

export const DailyRewardModal: React.FC<DailyRewardModalProps> = ({
  isOpen,
  onClose,
  onClaimReward,
  settings,
}) => {
  const [spinning, setSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [claimedAmount, setClaimedAmount] = useState<number | null>(null);

  if (!isOpen) return null;

  const isIndo = settings.language === 'id';

  const prizes = [500, 1000, 2500, 5000, 10000, 25000, 50000, 100000];

  const handleSpin = () => {
    if (spinning || claimedAmount !== null) return;
    setSpinning(true);

    // Pick random prize
    const prizeIndex = Math.floor(Math.random() * prizes.length);
    const prize = prizes[prizeIndex];

    const segmentAngle = 360 / prizes.length;
    const targetAngle = 360 * 5 + (360 - (prizeIndex * segmentAngle + segmentAngle / 2));

    setRotation(targetAngle);

    setTimeout(() => {
      setSpinning(false);
      setClaimedAmount(prize);
      confetti({
        particleCount: 60,
        spread: 80,
        origin: { y: 0.6 },
      });
    }, 3500);
  };

  const handleClaim = () => {
    if (claimedAmount) {
      onClaimReward(claimedAmount);
      setClaimedAmount(null);
      setRotation(0);
      onClose();
    }
  };

  return (
    <div id="modal-daily-reward" className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-6 text-white shadow-2xl relative text-center flex flex-col items-center">
        {/* Close Button */}
        <button
          id="btn-close-daily"
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-all"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Title */}
        <div className="w-14 h-14 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center mb-3">
          <Gift className="w-7 h-7" />
        </div>
        <h2 className="text-xl font-black text-amber-300">
          {isIndo ? 'Bonus Roda Hadiah Harian' : 'Daily Wheel of Fortune'}
        </h2>
        <p className="text-xs text-slate-400 mt-1 max-w-xs font-medium">
          {isIndo
            ? 'Putar roda setiap hari untuk klaim saldo kas gratis!'
            : 'Spin the wheel daily for free cash top-ups!'}
        </p>

        {/* Wheel Container */}
        <div className="relative my-6 w-56 h-56 flex items-center justify-center">
          {/* Wheel Pointer */}
          <div className="absolute -top-3 left-1/2 -translate-x-1/2 z-20 w-0 h-0 border-x-8 border-x-transparent border-t-[16px] border-t-amber-400 drop-shadow-md"></div>

          {/* Rotating Wheel */}
          <div
            className="w-full h-full rounded-full border-4 border-amber-400/80 shadow-2xl relative overflow-hidden transition-all duration-[3500ms] ease-out"
            style={{
              transform: `rotate(${rotation}deg)`,
              background: 'conic-gradient(#0f172a 0 45deg, #1e293b 45deg 90deg, #0f172a 90deg 135deg, #1e293b 135deg 180deg, #0f172a 180deg 225deg, #1e293b 225deg 270deg, #0f172a 270deg 315deg, #1e293b 315deg 360deg)',
            }}
          >
            {prizes.map((amt, idx) => {
              const angle = idx * (360 / prizes.length) + 22.5;
              return (
                <div
                  key={amt}
                  className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 font-black text-[10px] text-amber-300"
                  style={{
                    transform: `rotate(${angle}deg) translateY(-85px)`,
                  }}
                >
                  ${amt >= 1000 ? `${amt / 1000}k` : amt}
                </div>
              );
            })}
          </div>

          {/* Center Wheel Hub */}
          <div className="absolute w-12 h-12 rounded-full bg-amber-400 text-slate-950 font-black text-xs flex items-center justify-center shadow-lg border-2 border-slate-900 z-10">
            CASH
          </div>
        </div>

        {/* Action Button */}
        {claimedAmount ? (
          <div className="w-full flex flex-col items-center gap-3">
            <div className="text-2xl font-black text-emerald-400 animate-bounce flex items-center gap-1">
              <Sparkles className="w-6 h-6" />
              +${claimedAmount.toLocaleString()}
            </div>
            <button
              id="btn-claim-bonus"
              onClick={handleClaim}
              className="w-full py-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-black text-sm uppercase tracking-wider shadow-lg shadow-emerald-500/20 hover:brightness-110"
            >
              {isIndo ? 'Klaim Hadiah' : 'Claim Bonus'}
            </button>
          </div>
        ) : (
          <button
            id="btn-spin-wheel"
            onClick={handleSpin}
            disabled={spinning}
            className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 font-black text-sm uppercase tracking-wider shadow-lg shadow-amber-500/20 hover:brightness-110 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
          >
            <RotateCw className={`w-4 h-4 ${spinning ? 'animate-spin' : ''}`} />
            <span>{spinning ? (isIndo ? 'Memutar...' : 'Spinning...') : (isIndo ? 'Putar Roda' : 'Spin Wheel')}</span>
          </button>
        )}
      </div>
    </div>
  );
};
