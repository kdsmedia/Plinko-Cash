import React, { useState } from 'react';
import { GameSettings } from '../types';
import { X, Wallet, CheckCircle2, AlertCircle, ArrowRight, Loader2 } from 'lucide-react';
import { soundManager } from '../utils/audio';

interface WithdrawModalProps {
  isOpen: boolean;
  onClose: () => void;
  cash: number;
  onWithdraw: (amount: number) => void;
  settings: GameSettings;
}

const NOMINAL_OPTIONS = [200, 500, 1000, 2000, 5000, 10000];

export const WithdrawModal: React.FC<WithdrawModalProps> = ({
  isOpen,
  onClose,
  cash,
  onWithdraw,
  settings,
}) => {
  const [danaName, setDanaName] = useState('');
  const [danaPhone, setDanaPhone] = useState('');
  const [selectedAmount, setSelectedAmount] = useState<number>(500);
  const [isProcessing, setIsProcessing] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const isIndo = settings.language === 'id';

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    if (!danaName.trim()) {
      setErrorMsg(isIndo ? 'Masukkan nama lengkap sesuai DANA!' : 'Enter full name as registered on DANA!');
      return;
    }

    if (!danaPhone.trim() || danaPhone.length < 9) {
      setErrorMsg(isIndo ? 'Masukkan nomor DANA yang valid (cth: 081234567890)!' : 'Enter a valid DANA number!');
      return;
    }

    if (cash < selectedAmount) {
      setErrorMsg(isIndo ? `Saldo Kas tidak cukup untuk tarik Rp ${selectedAmount.toLocaleString()}!` : 'Insufficient cash balance!');
      return;
    }

    setIsProcessing(true);
    soundManager.playButtonClick();

    setTimeout(() => {
      setIsProcessing(false);
      onWithdraw(selectedAmount);
      soundManager.playWinSound();
      setSuccessMsg(
        isIndo
          ? `Penarikan Rp ${selectedAmount.toLocaleString()} sukses diproses ke DANA ${danaPhone} (${danaName})!`
          : `Withdrawal of Rp ${selectedAmount.toLocaleString()} sent to DANA ${danaPhone}!`
      );
    }, 1800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/80 backdrop-blur-md animate-fadeIn select-none">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 max-w-sm w-full text-white shadow-2xl relative flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 flex items-center justify-center shrink-0">
              <Wallet className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-black text-cyan-300">
                {isIndo ? 'Penarikan Saldo DANA' : 'DANA Cash Withdrawal'}
              </h2>
              <p className="text-[11px] text-slate-400">
                {isIndo ? 'Tarik hasil kemenangan ke akun DANA' : 'Cash out winnings to DANA account'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current Balance Banner */}
        <div className="bg-slate-950 border border-slate-800 rounded-2xl p-3 my-3.5 flex items-center justify-between">
          <span className="text-xs text-slate-400 font-bold">
            {isIndo ? 'Saldo Kas Tersedia:' : 'Available Balance:'}
          </span>
          <span className="text-emerald-400 font-black text-base font-mono">
            Rp {cash.toLocaleString()}
          </span>
        </div>

        {/* Form Inputs */}
        <form onSubmit={handleSubmit} className="flex flex-col gap-3">
          {/* DANA Name Input */}
          <div className="flex flex-col gap-1">
            <label className="text-[11px] font-bold text-slate-300">
              {isIndo ? 'Nama Pemilik DANA' : 'DANA Account Name'}
            </label>
            <input
              type="text"
              placeholder={isIndo ? 'Contoh: Budi Santoso' : 'e.g. John Doe'}
              value={danaName}
              onChange={(e) => setDanaName(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs font-bold text-white placeholder:text-slate-600 focus:outline-none focus:border-cyan-500"
            />
          </div>

          {/* DANA Phone Input */}
          <div className="flex flex-col gap-1">
            <label className="text-[11px] font-bold text-slate-300">
              {isIndo ? 'Nomor HP DANA' : 'DANA Phone Number'}
            </label>
            <input
              type="tel"
              placeholder={isIndo ? 'Contoh: 081234567890' : 'e.g. 081234567890'}
              value={danaPhone}
              onChange={(e) => setDanaPhone(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs font-bold text-white placeholder:text-slate-600 focus:outline-none focus:border-cyan-500 font-mono"
            />
          </div>

          {/* Nominal Grid (3 per row) */}
          <div className="flex flex-col gap-1.5 mt-1">
            <label className="text-[11px] font-bold text-slate-300">
              {isIndo ? 'Pilih Nominal Penarikan' : 'Select Nominal Amount'}
            </label>
            <div className="grid grid-cols-3 gap-2">
              {NOMINAL_OPTIONS.map((amt) => {
                const isSelected = selectedAmount === amt;
                const isDisabled = cash < amt;

                return (
                  <button
                    type="button"
                    key={amt}
                    onClick={() => setSelectedAmount(amt)}
                    className={`py-2 px-1 rounded-xl text-xs font-black transition-all border ${
                      isSelected
                        ? 'bg-cyan-500 text-slate-950 border-cyan-300 shadow-md shadow-cyan-500/20'
                        : isDisabled
                        ? 'bg-slate-950/50 text-slate-600 border-slate-800/80 cursor-not-allowed'
                        : 'bg-slate-950 text-slate-300 border-slate-800 hover:text-white hover:border-slate-700'
                    }`}
                  >
                    Rp {amt >= 1000 ? `${amt / 1000}k` : amt}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Messages */}
          {errorMsg && (
            <div className="flex items-center gap-1.5 text-red-400 text-[11px] font-bold bg-red-500/10 border border-red-500/20 rounded-xl p-2.5">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {successMsg && (
            <div className="flex items-center gap-1.5 text-emerald-400 text-[11px] font-bold bg-emerald-500/10 border border-emerald-500/20 rounded-xl p-2.5">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>{successMsg}</span>
            </div>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isProcessing}
            className="w-full mt-2 py-3 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-500 text-slate-950 font-black text-xs sm:text-sm uppercase tracking-wider shadow-lg shadow-cyan-500/20 hover:brightness-110 active:scale-95 transition-all flex items-center justify-center gap-2 disabled:opacity-50 touch-manipulation"
          >
            {isProcessing ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin text-slate-950" />
                <span>{isIndo ? 'Memproses DANA...' : 'Processing DANA...'}</span>
              </>
            ) : (
              <>
                <span>{isIndo ? 'TARIK SALDO SEKARANG' : 'WITHDRAW NOW'}</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
};
