import React from 'react';
import { GameSettings } from '../types';
import {
  Play,
  RotateCw,
} from 'lucide-react';

interface ControlPanelProps {
  cash: number;
  onDropBall: () => void;
  isAutoDropping: boolean;
  setIsAutoDropping: React.Dispatch<React.SetStateAction<boolean>>;
  settings: GameSettings;
  disabled?: boolean;
}

export const ControlPanel: React.FC<ControlPanelProps> = ({
  cash,
  onDropBall,
  isAutoDropping,
  setIsAutoDropping,
  settings,
  disabled = false,
}) => {
  const isIndo = settings.language === 'id';

  const handleDropWithHaptic = () => {
    if (typeof window !== 'undefined' && 'vibrate' in navigator && settings.soundEnabled) {
      try {
        navigator.vibrate(20);
      } catch {}
    }
    onDropBall();
  };

  const handleAutoToggleWithHaptic = () => {
    if (typeof window !== 'undefined' && 'vibrate' in navigator && settings.soundEnabled) {
      try {
        navigator.vibrate(30);
      } catch {}
    }
    setIsAutoDropping((prev) => !prev);
  };

  return (
    <div id="control-panel" className="w-full bg-slate-900/95 border border-slate-800/80 rounded-2xl p-3 sm:p-4 text-white shadow-2xl backdrop-blur-md flex flex-col gap-3 select-none">
      {/* Main Action Buttons: Drop Ball & Auto Drop */}
      <div className="grid grid-cols-2 gap-2.5">
        {/* Drop Single Ball Button */}
        <button
          id="btn-drop-ball"
          onClick={handleDropWithHaptic}
          disabled={disabled}
          className="py-3 px-3 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 text-slate-950 font-black text-xs sm:text-sm uppercase tracking-wider shadow-lg shadow-amber-500/25 hover:brightness-110 active:scale-95 transition-all flex items-center justify-center gap-1.5 disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap touch-manipulation"
        >
          <Play className="w-4 h-4 fill-slate-950 shrink-0" />
          <span>{isIndo ? 'Jatuhkan' : 'Drop'}</span>
        </button>

        {/* Auto Drop Toggle */}
        <button
          id="btn-auto-drop"
          onClick={handleAutoToggleWithHaptic}
          disabled={disabled}
          className={`py-3 px-3 rounded-2xl font-black text-xs sm:text-sm uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 border whitespace-nowrap active:scale-95 touch-manipulation ${
            isAutoDropping
              ? 'bg-emerald-500 text-slate-950 border-emerald-400 shadow-lg shadow-emerald-500/25 animate-pulse'
              : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700 shadow-md'
          }`}
        >
          <RotateCw className={`w-4 h-4 shrink-0 ${isAutoDropping ? 'animate-spin' : ''}`} />
          <span>{isAutoDropping ? (isIndo ? 'Stop' : 'Stop') : (isIndo ? 'Auto' : 'Auto')}</span>
        </button>
      </div>
    </div>
  );
};

