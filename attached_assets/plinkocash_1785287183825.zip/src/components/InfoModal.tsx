import React, { useState } from 'react';
import { GameSettings } from '../types';
import { Info, X, ShieldCheck, AlertTriangle, HelpCircle, FileText } from 'lucide-react';

interface InfoModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: GameSettings;
}

type InfoTab = 'about' | 'disclaimer' | 'privacy';

export const InfoModal: React.FC<InfoModalProps> = ({
  isOpen,
  onClose,
  settings,
}) => {
  const [activeTab, setActiveTab] = useState<InfoTab>('about');
  const isIndo = settings.language === 'id';

  if (!isOpen) return null;

  return (
    <div id="modal-info" className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-3 select-none animate-fadeIn">
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-5 text-white shadow-2xl relative flex flex-col max-h-[90vh]">
        {/* Close Button */}
        <button
          id="btn-close-info-modal"
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-all"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-4 pr-8">
          <div className="w-10 h-10 rounded-2xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400 shrink-0">
            <Info className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-black text-cyan-300">
              {isIndo ? 'Informasi & Ketentuan' : 'App Info & Legal'}
            </h2>
            <p className="text-[11px] text-slate-400">
              Plinko Cash Android Game
            </p>
          </div>
        </div>

        {/* Navigation Tabs (3 across) */}
        <div className="grid grid-cols-3 gap-1.5 p-1 bg-slate-950 rounded-2xl border border-slate-800 mb-4">
          <button
            onClick={() => setActiveTab('about')}
            className={`py-2 px-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'about'
                ? 'bg-cyan-500 text-slate-950 font-black shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <HelpCircle className="w-3.5 h-3.5" />
            <span>About</span>
          </button>

          <button
            onClick={() => setActiveTab('disclaimer')}
            className={`py-2 px-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'disclaimer'
                ? 'bg-amber-500 text-slate-950 font-black shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>Disclaimer</span>
          </button>

          <button
            onClick={() => setActiveTab('privacy')}
            className={`py-2 px-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'privacy'
                ? 'bg-emerald-500 text-slate-950 font-black shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Privacy</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="overflow-y-auto pr-1 flex-1 text-xs text-slate-300 flex flex-col gap-3">
          {activeTab === 'about' && (
            <div className="space-y-3 animate-fadeIn">
              <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800">
                <div className="flex items-center gap-2 text-cyan-400 font-bold mb-1">
                  <FileText className="w-4 h-4" />
                  <span>{isIndo ? 'Tentang Plinko Cash' : 'About Plinko Cash'}</span>
                </div>
                <p className="text-slate-300 text-xs leading-relaxed">
                  {isIndo
                    ? 'Plinko Cash adalah permainan seru dan interaktif untuk mengumpulkan poin terbanyak! Nikmati pengalaman seru menjatuhkan bola di papan plinko, memutar Roda Keberuntungan, dan menambah poin permainan Anda.'
                    : 'Plinko Cash is a fun and exciting game to collect points! Enjoy dropping balls down the plinko board, spinning the lucky wheel, and gathering high score points.'}
                </p>
              </div>

              <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800">
                <div className="text-amber-400 font-bold mb-1">{isIndo ? 'Fitur Utama Game:' : 'Key Game Features:'}</div>
                <ul className="list-disc list-inside text-slate-400 space-y-1 text-[11px]">
                  <li>{isIndo ? 'Simulasi Fisika Plinko Real-time' : 'Real-time Physics Engine'}</li>
                  <li>{isIndo ? 'Roda Keberuntungan Spin Wheel' : '10-Prize Lucky Spin Wheel'}</li>
                  <li>{isIndo ? 'Kumpulkan & Tukar Poin Permainan' : 'Collect & Exchange Game Points'}</li>
                  <li>{isIndo ? 'Bonus Hadiah Bola Gratis' : 'Bonus Free Balls Rewards'}</li>
                  <li>{isIndo ? 'Tampilan Responsif Mobile Native' : 'Responsive Mobile Interface'}</li>
                </ul>
              </div>
            </div>
          )}

          {activeTab === 'disclaimer' && (
            <div className="space-y-3 animate-fadeIn">
              <div className="bg-amber-500/10 border border-amber-500/30 p-3.5 rounded-2xl">
                <div className="flex items-center gap-2 text-amber-400 font-bold mb-1">
                  <AlertTriangle className="w-4 h-4" />
                  <span>{isIndo ? 'Pernyataan Permainan (Disclaimer)' : 'Game Disclaimer'}</span>
                </div>
                <p className="text-amber-200/90 text-[11px] leading-relaxed">
                  {isIndo
                    ? 'Aplikasi ini dibuat murni untuk hiburan dan keseruan bermain. Seluruh angka poin dan item dalam game ini adalah skor virtual hiburan semata.'
                    : 'This application is designed purely for entertainment and casual fun. All point values and items in this game are virtual simulation scores.'}
                </p>
              </div>

              <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800">
                <p className="text-slate-400 text-[11px] leading-relaxed">
                  {isIndo
                    ? 'Permainan ini dirancang khusus untuk memberikan pengalaman seru dalam mengumpulkan poin terbanyak dan menguji ketangkasan. Selamat bermain dan raih skor poin tertinggi!'
                    : 'This game is designed to offer an exciting experience of accumulating high points and testing your luck. Have fun playing and reach the highest score!'}
                </p>
              </div>
            </div>
          )}

          {activeTab === 'privacy' && (
            <div className="space-y-3 animate-fadeIn">
              <div className="bg-emerald-500/10 border border-emerald-500/30 p-3.5 rounded-2xl">
                <div className="flex items-center gap-2 text-emerald-400 font-bold mb-1">
                  <ShieldCheck className="w-4 h-4" />
                  <span>{isIndo ? 'Kebijakan Privasi' : 'Privacy Policy'}</span>
                </div>
                <p className="text-emerald-200/90 text-[11px] leading-relaxed">
                  {isIndo
                    ? 'Kami berkomitmen penuh untuk melindungi privasi pengguna. Seluruh progres permainan, jumlah sisa bola, saldo poin virtual, dan riwayat permainan disimpan secara lokal di dalam memori perangkat Anda (LocalStorage).'
                    : 'We are committed to protecting user privacy. All game progress, remaining balls, virtual points, and history are saved strictly locally on your device storage (LocalStorage).'}
                </p>
              </div>

              <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800 text-[11px] text-slate-400 space-y-1.5">
                <p>
                  {isIndo
                    ? '• Kami tidak pernah menjual atau membagikan data pribadi Anda.'
                    : '• We do not sell or share any personal user data.'}
                </p>
                <p>
                  {isIndo
                    ? '• Tidak ada pendaftaran akun atau pencatatan server eksternal.'
                    : '• No account registration or external tracking servers required.'}
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-500">
       
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold transition-all"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
