import React from 'react';
import { GameSettings } from '../types';
import {
  Volume2,
  VolumeX,
  Info,
  Smartphone,
  Gift,
  Wallet,
  Plus,
  CircleDot,
} from 'lucide-react';

interface HeaderProps {
  cash: number;
  ballsCount: number;
  settings: GameSettings;
  setSettings: React.Dispatch<React.SetStateAction<GameSettings>>;
  onOpenDaily: () => void;
  onOpenInfo: () => void;
  onOpenSpinWheel: () => void;
  onOpenWithdraw: () => void;
  onOpenAdReward: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  cash,
  ballsCount,
  settings,
  setSettings,
  onOpenDaily,
  onOpenInfo,
  onOpenSpinWheel,
  onOpenWithdraw,
  onOpenAdReward,
}) => {
  const isIndo = settings.language === 'id';

  const toggleSound = () => {
    setSettings((prev) => ({ ...prev, soundEnabled: !prev.soundEnabled }));
  };

  const toggleLanguage = () => {
    setSettings((prev) => ({
      ...prev,
      language: prev.language === 'id' ? 'en' : 'id',
    }));
  };

  const toggleMobileFrame = () => {
    setSettings((prev) => ({ ...prev, mobileFrame: !prev.mobileFrame }));
  };

  return (
    <header id="header-bar" className="w-full bg-slate-900/95 border-b border-slate-800/80 text-white px-2.5 sm:px-6 py-2 backdrop-blur-md sticky top-0 z-30 shadow-lg select-none">
      <div className="max-w-6xl mx-auto flex items-center justify-between gap-1.5 sm:gap-2">
        {/* Brand & Logo */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-gradient-to-tr from-amber-500 via-yellow-400 to-amber-300 p-0.5 shadow-md shadow-amber-500/20 flex items-center justify-center shrink-0">
            <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center font-black text-amber-400 text-base sm:text-lg">
              P
            </div>
          </div>
          <div className="hidden xs:block">
            <h1 className="font-extrabold text-xs sm:text-lg tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-amber-300 via-yellow-400 to-amber-200 leading-none">
              Plinko Cash
            </h1>
            <span className="text-[9px] sm:text-[10px] text-slate-400 font-medium tracking-wide flex items-center gap-1 mt-0.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
              Android Game
            </span>
          </div>
        </div>

        {/* Top Badges: Remaining Balls & DANA Wallet */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Remaining Balls Badge with + Button */}
          <div className="bg-slate-950 border border-amber-500/40 rounded-xl px-2 py-1 flex items-center gap-1.5 shadow-inner">
            <CircleDot className="w-3.5 h-3.5 text-amber-400 animate-pulse shrink-0" />
            <div className="flex flex-col">
              <span className="text-[8px] sm:text-[9px] text-amber-400/80 font-bold uppercase leading-none">
                {isIndo ? 'Sisa Bola' : 'Balls'}
              </span>
              <span className="text-xs sm:text-sm font-black text-amber-300 leading-tight">
                {ballsCount}
              </span>
            </div>
            {/* Plus button to watch ad or exchange points */}
            <button
              id="btn-add-balls-ad"
              onClick={onOpenAdReward}
              title={isIndo ? 'Tambah Bola (+2 Iklan / Tukar Poin)' : 'Get Balls (+2 Ad / Exchange)'}
              className="ml-0.5 p-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-black flex items-center justify-center shadow transition-all active:scale-95 touch-manipulation"
            >
              <Plus className="w-3.5 h-3.5 stroke-[3]" />
            </button>
          </div>

          {/* DANA Wallet Balance Badge & Withdraw Button */}
          <button
            id="btn-wallet-withdraw"
            onClick={onOpenWithdraw}
            title={isIndo ? 'Tarik Saldo DANA' : 'Withdraw DANA'}
            className="bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 border border-cyan-500/50 hover:border-cyan-400 rounded-xl px-2.5 py-1 flex items-center gap-1.5 shadow-inner transition-all active:scale-95 touch-manipulation group"
          >
            <div className="w-5 h-5 sm:w-6 sm:h-6 rounded-lg bg-cyan-500/20 text-cyan-400 flex items-center justify-center font-bold text-xs shrink-0 group-hover:bg-cyan-500 group-hover:text-slate-950 transition-colors">
              <Wallet className="w-3.5 h-3.5" />
            </div>
            <div className="text-left">
              <div className="text-[8px] sm:text-[9px] text-cyan-400/80 font-bold uppercase leading-none flex items-center gap-1">
                <span>DANA</span>
                <span className="text-[8px] bg-cyan-500/20 text-cyan-300 px-1 rounded font-mono">Tarik</span>
              </div>
              <div className="text-xs sm:text-sm font-extrabold text-cyan-300 tracking-tight leading-tight">
                Rp {cash.toLocaleString('id-ID')}
              </div>
            </div>
          </button>
        </div>

        {/* Quick Icon Controls */}
        <div className="flex items-center gap-1">
          {/* Gift Icon -> Spin Wheel Modal */}
          <button
            id="btn-gift-spin"
            onClick={onOpenSpinWheel}
            title={isIndo ? 'Roda Keberuntungan Hadiah' : 'Lucky Spin Wheel'}
            className="p-1.5 sm:p-2 rounded-xl bg-gradient-to-r from-amber-500/20 to-yellow-500/20 hover:from-amber-500/30 hover:to-yellow-500/30 text-amber-300 border border-amber-500/40 transition-all relative active:scale-95 touch-manipulation"
          >
            <Gift className="w-4 h-4 animate-bounce" />
            <span className="absolute -top-1 -right-1 w-2 h-2 bg-amber-400 rounded-full animate-ping"></span>
          </button>

          {/* Sound Toggle */}
          <button
            id="btn-toggle-sound"
            onClick={toggleSound}
            title={settings.soundEnabled ? 'Mute' : 'Unmute'}
            className="p-1.5 sm:p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition-all active:scale-95 touch-manipulation hidden xs:flex"
          >
            {settings.soundEnabled ? <Volume2 className="w-4 h-4 text-emerald-400" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
          </button>

          {/* Mobile Frame Toggle */}
          <button
            id="btn-toggle-mobile"
            onClick={toggleMobileFrame}
            title={isIndo ? 'Simulasi Frame HP' : 'Mobile Frame Preview'}
            className={`p-1.5 sm:p-2 rounded-xl border transition-all active:scale-95 touch-manipulation hidden sm:flex ${
              settings.mobileFrame
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                : 'bg-slate-800/80 text-slate-400 border-slate-700 hover:text-white'
            }`}
          >
            <Smartphone className="w-4 h-4" />
          </button>

          {/* Language Toggle */}
          <button
            id="btn-toggle-lang"
            onClick={toggleLanguage}
            title={isIndo ? 'Ganti Bahasa' : 'Switch Language'}
            className="p-1.5 sm:p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition-all text-xs font-bold active:scale-95 touch-manipulation hidden sm:flex"
          >
            {settings.language.toUpperCase()}
          </button>

          {/* Info Button (About, Disclaimer, Privacy Policy) */}
          <button
            id="btn-info"
            onClick={onOpenInfo}
            title={isIndo ? 'Informasi App' : 'App Info'}
            className="p-1.5 sm:p-2 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 transition-all active:scale-95 touch-manipulation"
          >
            <Info className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
